package br.com.minhasnotas;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final ArrayList<Note> notes = new ArrayList<>();
    private LinearLayout listContainer;
    private EditText searchInput;
    private SharedPreferences prefs;
    private int ink = Color.rgb(34, 39, 52);
    private int muted = Color.rgb(116, 123, 139);
    private int purple = Color.rgb(100, 80, 220);
    private int paper = Color.rgb(247, 247, 251);

    static class Note {
        String title, body, updated;
        Note(String t, String b, String u) { title=t; body=b; updated=u; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("notes_data", MODE_PRIVATE);
        loadNotes();
        buildScreen();
        renderNotes();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 28, 22, 18);
        page.setBackgroundColor(paper);

        TextView title = label("Minhas Notas", 29, ink, true);
        page.addView(title);

        TextView subtitle = label("Suas ideias, sempre à mão.", 14, muted, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, -2);
        subp.topMargin = 4; subp.bottomMargin = 20;
        page.addView(subtitle, subp);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(15);
        searchInput.setHint("Pesquisar notas...");
        searchInput.setPadding(16, 8, 16, 8);
        searchInput.setBackground(shape(Color.WHITE, 22));
        page.addView(searchInput, new LinearLayout.LayoutParams(-1, 52));
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderNotes(); }
            public void afterTextChanged(android.text.Editable e) {}
        });

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(0, 22, 0, 12);
        TextView recent = label("Todas as notas", 18, ink, true);
        heading.addView(recent, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = label(notes.size() + " notas", 12, muted, false);
        heading.addView(count);
        page.addView(heading);

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listContainer);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button add = new Button(this);
        add.setText("+  Nova anotação");
        add.setTextColor(Color.WHITE);
        add.setTextSize(16);
        add.setAllCaps(false);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(shape(purple, 28));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 54);
        bp.topMargin = 12;
        page.addView(add, bp);
        add.setOnClickListener(v -> showEditor(-1));

        setContentView(page);
    }

    private void renderNotes() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        String query = searchInput == null ? "" : searchInput.getText().toString().toLowerCase(Locale.ROOT).trim();
        int shown = 0;
        for (int i = notes.size() - 1; i >= 0; i--) {
            Note n = notes.get(i);
            if (!(n.title.toLowerCase(Locale.ROOT).contains(query) || n.body.toLowerCase(Locale.ROOT).contains(query))) continue;
            final int index = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(17, 15, 17, 13);
            card.setBackground(shape(Color.WHITE, 18));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = 11;
            listContainer.addView(card, cp);

            TextView nt = label(n.title.isEmpty() ? "Sem título" : n.title, 17, ink, true);
            card.addView(nt);
            TextView body = label(n.body.isEmpty() ? " " : n.body, 14, muted, false);
            body.setMaxLines(3);
            LinearLayout.LayoutParams bodyp = new LinearLayout.LayoutParams(-1, -2);
            bodyp.topMargin = 7;
            card.addView(body, bodyp);
            TextView date = label(n.updated, 11, muted, false);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
            dp.topMargin = 10;
            card.addView(date, dp);
            card.setOnClickListener(v -> showEditor(index));
            card.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("Excluir anotação?")
                    .setMessage("Esta ação não pode ser desfeita.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Excluir", (d,w) -> { notes.remove(index); saveNotes(); renderNotes(); })
                    .show();
                return true;
            });
            shown++;
        }
        if (shown == 0) {
            TextView empty = label(query.isEmpty() ? "Nenhuma anotação ainda.\nToque em “Nova anotação” para começar." : "Nenhuma nota encontrada.", 15, muted, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(16, 48, 16, 48);
            listContainer.addView(empty);
        }
    }

    private void showEditor(int index) {
        boolean editing = index >= 0;
        Note old = editing ? notes.get(index) : new Note("", "", "");
        LinearLayout form = new LinearLayout(this);
        form.setPadding(20, 8, 20, 0);
        form.setOrientation(LinearLayout.VERTICAL);
        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setTextSize(18);
        title.setHint("Título");
        title.setText(old.title);
        EditText body = new EditText(this);
        body.setTextSize(16);
        body.setGravity(Gravity.TOP);
        body.setMinLines(7);
        body.setHint("Escreva sua anotação...");
        body.setText(old.body);
        form.addView(title);
        form.addView(body, new LinearLayout.LayoutParams(-1, -2));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(editing ? "Editar anotação" : "Nova anotação")
            .setView(form)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar", null)
            .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            String b = body.getText().toString().trim();
            if (t.isEmpty() && b.isEmpty()) {
                Toast.makeText(this, "Escreva algo antes de salvar.", Toast.LENGTH_SHORT).show();
                return;
            }
            String stamp = new SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", new Locale("pt", "BR")).format(new Date());
            Note note = new Note(t, b, "Atualizada em " + stamp);
            if (editing) notes.set(index, note); else notes.add(note);
            saveNotes();
            renderNotes();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void loadNotes() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("notes", "[]"));
            for (int i=0; i<arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                notes.add(new Note(o.optString("title"), o.optString("body"), o.optString("updated")));
            }
        } catch (Exception ignored) {}
    }

    private void saveNotes() {
        JSONArray arr = new JSONArray();
        for (Note n : notes) {
            JSONObject o = new JSONObject();
            try {
                o.put("title", n.title); o.put("body", n.body); o.put("updated", n.updated);
                arr.put(o);
            } catch (Exception ignored) {}
        }
        prefs.edit().putString("notes", arr.toString()).apply();
    }
}
